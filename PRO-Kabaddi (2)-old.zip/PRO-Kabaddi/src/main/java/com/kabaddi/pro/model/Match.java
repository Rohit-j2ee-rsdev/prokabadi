package com.kabaddi.pro.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
public class Match implements Serializable{

	private static final long serialVersionUID = 862378770190262427L;

	private int matchId;

	private Team[] teams;
	private String location;
	private LocalDate date;

	public Match(Team[] teams) {
		super();
		this.teams = teams;
	}

}
