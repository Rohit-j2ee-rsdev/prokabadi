package com.kabaddi.pro.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kabaddi.pro.model.Match;
import com.kabaddi.pro.model.Team;

@Repository
public interface TeamRepository extends JpaRepository<Team, Integer>{

	
}
