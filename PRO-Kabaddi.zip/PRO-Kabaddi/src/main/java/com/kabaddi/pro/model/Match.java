package com.kabaddi.pro.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Match implements Serializable{

	private static final long serialVersionUID = 862378770190262427L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int matchId;

	private int homeTmRefid;
	private int visitorTmRefid;
	
	private String location;
	private LocalDate date;
	
	
	public Match(int homeTmRefid, int visitorTmRefid) {
		super();
		this.homeTmRefid = homeTmRefid;
		this.visitorTmRefid = visitorTmRefid;
	}
	
	


}
