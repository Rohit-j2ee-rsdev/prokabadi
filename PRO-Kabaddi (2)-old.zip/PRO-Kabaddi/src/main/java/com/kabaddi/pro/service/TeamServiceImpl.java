package com.kabaddi.pro.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kabaddi.pro.dao.TeamRepository;
import com.kabaddi.pro.model.Team;

@Service
@Transactional
public class TeamServiceImpl implements TeamService{

	@Autowired
	private TeamRepository teamRepository;
	
	@Override
	public List<Team> addTeam(List<Team> team) {
		return teamRepository.saveAll(team);
	}

	@Override
	public List<Team> findALL() {
		return teamRepository.findAll();
	}
}
