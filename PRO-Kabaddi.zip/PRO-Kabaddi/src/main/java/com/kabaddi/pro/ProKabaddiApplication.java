package com.kabaddi.pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProKabaddiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProKabaddiApplication.class, args);
	}

}
