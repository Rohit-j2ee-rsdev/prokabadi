package com.kabaddi.pro.util;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kabaddi.pro.dao.MatchRepository;
import com.kabaddi.pro.model.Match;
import com.kabaddi.pro.model.Team;

@Component
public class MatchSchedulerUtil {

	@Autowired
	private MatchRepository matchRepository;
	
	public List<Match> generate(List<Team> teams, LocalDateTime startDate) {
		// Generate matches from combination of teams
		List<Match> matches = initializeMatches(teams);
		
		
		// Define current date          
		LocalDateTime currentDate = LocalDateTime.now();
		
		// Loop till one of the match date has not been scheduled
		while (isMatchScheduleRemaining(matches)) {
			
			// Prepare already participated team id list
			List<Integer> participatedTeamIds = prepareParticipatedTeamList(matches, currentDate);

			// Swap object in list 
			Random random = new Random();
			Collections.swap(matches, random.nextInt(matches.size()), random.nextInt(matches.size()));
			
			for (Match match : matches) {
				
			//	Team[] tm=match.getTeams();
		//		for (int i = 0; i < tm.length; i++) {
					if (match.getDate() == null &&
							!participatedTeamIds.contains(match.getHomeTmRefid()) &&
							!participatedTeamIds.contains(match.getVisitorTmRefid())) {
						match.setDate(currentDate.toLocalDate());
						
						participatedTeamIds.add(match.getHomeTmRefid());
						participatedTeamIds.add(match.getHomeTmRefid());
					}
		//		}
					
			}
			// Increment current date by 2 days
			currentDate = currentDate.plusDays(2);
		}
		List<Match> matches1=matchRepository.saveAll(matches);
		return matches;
	}

	private List<Match> initializeMatches(List<Team> teams) {
		// Define matches to be return
		List<Match> matches = new ArrayList<Match>(teams.size()*(teams.size()-1));
		// Initialize matches
		int j=0;
		for (Team homeTm : teams) {
			for (Team visitorTm : teams) {
				
				if (homeTm.getTeamId() != visitorTm.getTeamId()) {
					
					//
				//	Team[] oppteams = new Team[] { homeTm, visitorTm };
					Match match = new Match(homeTm.getTeamId(), visitorTm.getTeamId());
					match.setLocation(homeTm.getLocation());
					match.setMatchId(j+1);
					j++;
					matches.add(match);
					//
					
				}
			}
		}

		// Return list of matches
		return matches;
	}

	private boolean isMatchScheduleRemaining(List<Match> matches) {
		for (Match match : matches) {
			if (match.getDate() == null) {
				return true;
			}
		}
		return false;
	}

	@SuppressWarnings("unlikely-arg-type")
	private List<Integer> prepareParticipatedTeamList(List<Match> matches, LocalDateTime date) {
		List<Integer> teamIds = new ArrayList<Integer>();
		for (Match match : matches) {
			if (match.getDate() != null) {
				if (date.equals(match.getDate())) {
					//Team[] team=match.getTeams();
				//	Team teamA=team[0];
					
		//			List<Team> paricipatedTeams=Arrays.asList(match.getTeams());
				//	paricipatedTeams.get(0).getTeamId();
					teamIds.add(match.getHomeTmRefid());
					teamIds.add(match.getVisitorTmRefid());
				}
			}
		}
		return teamIds;
	}

}
